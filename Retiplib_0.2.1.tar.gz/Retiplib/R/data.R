#' Retip library
#'
#' @docType data
#'
#' @usage data(retip_lib_v1)
#'
#' @keywords more than 16 different database with Retip Chemical descriptos calculated
#'
#' @references xxx
#'
#'
#' @examples
#' data(retip_lib_v1)

"retip_lib_v1"
